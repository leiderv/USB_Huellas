import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientListComponent } from './component/client-list/client-list.component';
import { DocumentTypeListComponent } from './component/document-type-list/document-type-list.component';
import { ClientSaveComponent } from './component/client-save/client-save.component';
import { ClientEditComponent } from './component/client-edit/client-edit.component';
import { FootprintCreateReleaseComponent } from './component/footprint-create-release/footprint-create-release.component';
import { FootprintListComponent } from './component/footprint-list/footprint-list.component';
import { FootprintCompararComponent } from './component/footprint-comparar/footprint-comparar.component';
import { FootprinttempListComponent } from './component/footprinttemp-list/footprinttemp-list.component';
import { AppComponent } from './app.component';

const routes: Routes = [
  {path:'client-list',component:ClientListComponent},
  {path:'document-type-list',component:DocumentTypeListComponent},
  {path:'client-save',component:ClientSaveComponent},
  {path:'client-edit/:id',component:ClientEditComponent},
  {path:'footprint-create-release',component:FootprintCreateReleaseComponent},
  {path:'footprint-list',component:FootprintListComponent},
  {path:'footprinttemp-list',component:FootprinttempListComponent},
  {path:'footprint-comparar',component:FootprintCompararComponent},
  {path:'AppIndex',component:AppComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
