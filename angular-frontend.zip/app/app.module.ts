import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';

import { ClientService } from './service/client.service';
import { ClientListComponent } from './component/client-list/client-list.component'
import { DocumentTypeListComponent } from './component/document-type-list/document-type-list.component';
import {DocumentTypeService} from './service/document-type.service';
import { ClientSaveComponent } from './component/client-save/client-save.component';
import { ClientEditComponent } from './component/client-edit/client-edit.component';
import { FootprintCreateReleaseComponent } from './component/footprint-create-release/footprint-create-release.component';
import { FootprintListComponent } from './component/footprint-list/footprint-list.component';
import { FootprintCompararComponent } from './component/footprint-comparar/footprint-comparar.component';
import { FootprinttempListComponent } from './component/footprinttemp-list/footprinttemp-list.component';


@NgModule({
  declarations: [
    AppComponent,
    ClientListComponent,
    DocumentTypeListComponent,
    ClientSaveComponent,
    ClientEditComponent,
    FootprintCreateReleaseComponent,
    FootprintListComponent,
    FootprintCompararComponent,
    FootprinttempListComponent
  ],

  /*modulos que se va llevar el instalador */
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  
  /*Se adiciona el ClientService para
  que se pueda ver el servicio en todo el proyecto */
  providers: [
    ClientService,
    DocumentTypeService,
    FootprinttempListComponent
  ],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
