import { Injectable } from '@angular/core';
import { Enable } from '../domain/enable';

@Injectable({
  providedIn: 'root'
})
export class EnableService {

  public listaEnable:Enable[];

  constructor() { 
    this.listaEnable=[
      {id:'S',name:'SI'},
      {id:'N',name:'NO'}
    ];
  }

  public findAll():Enable[]{
    return this.listaEnable;
  }
  
}
