import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Footprinttemp } from '../domain/footprinttemp';

@Injectable({
  providedIn: 'root'
})
export class FootprintTempService {
  public url:string;

  constructor(public httpClient:HttpClient) { 
    this.url=environment.apiUrl+'api/footprintTemp/'
  }

  public findAll():Observable<any>{
    return this.httpClient.get(this.url+'findAll');
  }

  public save(footprint:Footprinttemp):Observable<any>{
     return this.httpClient.post(this.url+'save',footprint);
  }

  public update(footprint:Footprinttemp):Observable<any>{
    return this.httpClient.put(this.url+'update',footprint);
  }

  public delete(id:string):Observable<any>{
    return this.httpClient.delete(this.url+'delete/'+id);
  }

  public findById(id:string):Observable<any>{
    return this.httpClient.get(this.url+'findById/'+id);
  }

  public comparar(release1:string,release2:string):Observable<any>{
    return this.httpClient.get(this.url+'comparar/'+release1+'/'+release2);
  }
}
