import { Component, OnInit, OnDestroy } from '@angular/core';
import { Footprint } from 'src/app/domain/footprint';
import { FootprintService } from 'src/app/service/footprint.service';
import { Footprinttemp } from 'src/app/domain/footprinttemp';
import { FootprintTempService } from 'src/app/service/footprinttemp.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-footprint-comparar',
  templateUrl: './footprint-comparar.component.html',
  styleUrls: ['./footprint-comparar.component.css']
})
export class FootprintCompararComponent implements OnInit,OnDestroy {
    public footprint:Footprint;
    public release1:string;
    public release2:string;
    public opt1:string;
    public opt2:string;
    public listaFootprint:Footprint[];
    public listaFootprinttemp:Footprinttemp[];
    public subListaFootprint:Subscription;
  
    constructor(public footprintService:FootprintService) { }
   
    findAllFootprint():void{
      this.subListaFootprint = this.footprintService.findAll().subscribe(data=>{
        this.listaFootprint=data;
      })
    }

    findAllFootprinttemp():void{
      this.subListaFootprint = this.footprintService.findAllTemp().subscribe(data=>{
        this.listaFootprinttemp=data;
        this.showMsg = true;
      })
    }
  
    public comparar(){   
      //console.table(this.release1);
      this.footprintService.comparar(this.release1,this.release2).subscribe(data=>{
        this.footprint = data
        this.findAllFootprinttemp();
        //console.table(this.footprint);        
        //this.msg='Comparado';
      });
    }

    capturar1() {
      // Pasamos el valor seleccionado a la variable verSeleccion
      this.release1 = this.opt1;
    }
  
    capturar2() {
      // Pasamos el valor seleccionado a la variable verSeleccion
      this.release2 = this.opt2;
    }

    /*getAllFootprint():void{
      this.subListaFootprint = this.footprintService.getAllGroup().subscribe(data=>{
        this.listaFootprint=data;
      })
    }*/

    ngOnInit(): void {
      this.findAllFootprint();
      //this.getAllFootprint();
    }
  
    ngOnDestroy(): void {
      this.subListaFootprint.unsubscribe();
    }
  
    public showMsg:boolean=false;
    public msg:string;
  
}
