import { Component, OnInit, OnDestroy } from '@angular/core';
import { FootprintService } from 'src/app/service/footprint.service';
import { Footprint } from 'src/app/domain/footprint';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-footprint-list',
  templateUrl: './footprint-list.component.html',
  styleUrls: ['./footprint-list.component.css']
})

export class FootprintListComponent implements OnInit,OnDestroy {

    public listaFootprint:Footprint[];
    public subListaFootprint:Subscription;
  
    constructor(public footprintService:FootprintService) { }
   
    findAllFootprint():void{
      this.subListaFootprint = this.footprintService.findAll().subscribe(data=>{
        this.listaFootprint=data;
      })
    }
  
    ngOnInit(): void {
      this.findAllFootprint();
    }
  
    ngOnDestroy(): void {
      this.subListaFootprint.unsubscribe();
    }
  
    public showMsg:boolean=false;
    public msg:string;
  
    
  }
  
