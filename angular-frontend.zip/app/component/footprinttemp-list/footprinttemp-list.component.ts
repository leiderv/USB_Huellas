import { Component, OnInit, OnDestroy } from '@angular/core';
import { FootprintTempService } from 'src/app/service/footprinttemp.service';
import { Footprinttemp } from 'src/app/domain/footprinttemp';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-footprinttemp-list',
  templateUrl: './footprinttemp-list.component.html',
  styleUrls: ['./footprinttemp-list.component.css']
})
export class FootprinttempListComponent implements OnInit {

  public listaFootprinttemp:Footprinttemp[];
    public subListaFootprint:Subscription;
  
    constructor(public footprinttempService:FootprintTempService) { }
   
    findAllFoottempprint():void{
      this.subListaFootprint = this.footprinttempService.findAll().subscribe(data=>{
        this.listaFootprinttemp=data;
      })
    }
  
    ngOnInit(): void {
      this.findAllFoottempprint();
    }
  
    ngOnDestroy(): void {
      this.subListaFootprint.unsubscribe();
    }
  
    public showMsg:boolean=false;
    public msg:string;
  

}
