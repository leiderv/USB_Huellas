import { Component, OnInit, OnDestroy } from '@angular/core';
import { Footprint } from 'src/app/domain/footprint';
import { FootprintService } from 'src/app/service/footprint.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-footprint-create-release',
  templateUrl: './footprint-create-release.component.html',
  styleUrls: ['./footprint-create-release.component.css']
})

export class FootprintCreateReleaseComponent implements OnInit {
  public footprint:Footprint;
  public id:string;
  public release:string;
  public showMsg:boolean=false;
  public msg:string;
  public subListaFootprint:Subscription;
  public listaFootprint:Footprint[];

  constructor(public footprintService:FootprintService) { }

  ngOnInit(): void {
    this.footprint=new Footprint(0,'','','','','');    
  }

  findAllByRelease(release:string):void{
    this.subListaFootprint = this.footprintService.findByRelease(release).subscribe(data=>{
      this.listaFootprint=data;
    })
  }

  public createRelease(id:string){         
    this.footprintService.createRelease(id).subscribe(data=>{
      //Para que no muestre en el campo lo que se devuelve
      this.footprint.release= ""
      this.findAllByRelease(id)
      this.showMsg = true;
      this.msg='Release creado';
    });
  }
}

