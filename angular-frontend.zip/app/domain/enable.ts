export class Enable {
    constructor(
        public id:string,
        public name:string
    ){}

}
