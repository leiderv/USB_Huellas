export class Footprinttemp {
    constructor(       
        public fpId:number,
        public release:string,
        public object_type:string,
        public object:string,
        public date:string,
        public hash:string,
        public hash_footprint:string
    ){}
}
