export class Footprint {
    constructor(       
        public fpId:number,
        public release:string,
        public object_type:string,
        public object:string,
        public date:string,
        public hash:string
    ){}
}
