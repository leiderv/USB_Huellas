package co.edu.usbcali.bank.dto;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class FootprintDTO {
	private Long fpId;
	
	@NotNull
	@NotEmpty
	@Size(max = 255)
	private String release;
	
	@NotNull
	@NotEmpty
	@Size(max = 255)	
	private String object_type;
	
	@NotNull
	@NotEmpty
	@Size(max = 255)
	private String object;
	
	@NotNull
	private String date;
	
	@NotNull
	@NotEmpty	
	private String hash;

	public FootprintDTO() {
		super();
	}

	public FootprintDTO(Long fpId, @NotNull @NotEmpty @Size(max = 255) String release,
			@NotNull @NotEmpty @Size(max = 255) String object_type, @NotNull @NotEmpty @Size(max = 255) String object,
			@NotNull String date, @NotNull @NotEmpty String hash) {
		super();
		this.fpId = fpId;
		this.release = release;
		this.object_type = object_type;
		this.object = object;
		this.date = date;
		this.hash = hash;
	}

	public Long getFpId() {
		return fpId;
	}

	public void setFpId(Long fpId) {
		this.fpId = fpId;
	}

	public String getRelease() {
		return release;
	}

	public void setRelease(String release) {
		this.release = release;
	}

	public String getObject_type() {
		return object_type;
	}

	public void setObject_type(String object_type) {
		this.object_type = object_type;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}
	
	
}
