package co.edu.usbcali.bank.service;

import co.edu.usbcali.bank.domain.FootprintTemp;

public interface FootPrintTempService extends GenericService<FootprintTemp,Long>{

}
