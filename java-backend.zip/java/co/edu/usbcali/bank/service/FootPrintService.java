package co.edu.usbcali.bank.service;

import java.util.List;
import java.util.Optional;

import co.edu.usbcali.bank.domain.Footprint;

public interface FootPrintService extends GenericService<Footprint,Long>{
	String createRelease(String release,String result);
	List<Footprint> getAllGroup();
	String comparar(String release1,String release2,String result);	
	List<Footprint> findByRelease(String release);
}
