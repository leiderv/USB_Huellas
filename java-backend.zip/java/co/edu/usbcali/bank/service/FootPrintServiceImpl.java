package co.edu.usbcali.bank.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.edu.usbcali.bank.domain.Footprint;
import co.edu.usbcali.bank.repository.FootPrintRepository;

@Service
public class FootPrintServiceImpl implements FootPrintService {
	@Autowired
	FootPrintRepository footPrintRepository;
	
	@Autowired
	Validator validator;
	
	//@Override
	//@Transactional(readOnly=true)
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public String createRelease(String release,String result){
		return footPrintRepository.createRelease(release,result);
	}	
	
	//@Override
	//@Transactional(readOnly=true)
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public String comparar(String release1,String release2,String result){
		return footPrintRepository.comparar(release1,release2,result);
	}
	
	//@Override
	@Transactional(readOnly=true)
	public List<Footprint> getAllGroup() {
		return footPrintRepository.getAllGroup();
	}
		
	@Override
	@Transactional(readOnly=true)
	public List<Footprint> findAll() {	
		HashMap<String,Footprint> map= new HashMap<String,Footprint>();
		List<Footprint> listaFootprint= footPrintRepository.findAll(); //new ArrayList<Footprint>();
		for(Footprint footprint:listaFootprint) {
			map.put(footprint.getRelease(), footprint);
		}
		
		Set<Entry<String,Footprint>> set = map.entrySet();
		List<Footprint> footprintNuevo= new ArrayList<Footprint>();
		for(Entry<String,Footprint> entry : set) {
			footprintNuevo.add(entry.getValue());				
		}
		return footprintNuevo;		
	}

	@Override
	@Transactional(readOnly=true)
	public Optional<Footprint> findById(Long id) {
		return footPrintRepository.findById(id);
	}
	
	//@Override
	@Transactional(readOnly=true)
	public List<Footprint> findByRelease(String id) {
		return footPrintRepository.findByRelease(id);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public Footprint save(Footprint entity) throws Exception {
		validate(entity);
		return footPrintRepository.save(entity);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public Footprint update(Footprint entity) throws Exception {
		validate(entity);
		return footPrintRepository.save(entity);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public void delete(Footprint entity) throws Exception {
		if(entity ==null) {
	    	throw new Exception("FootPrint Nulo");
	    }
	 
		Optional<Footprint> footprintOpcional=footPrintRepository.findById(entity.getFpId());
		if(footprintOpcional.isPresent()==false) {
			throw new Exception("El footprint "+entity.getFpId()+" no existe");
		}
		
		entity = footprintOpcional.get();						
		footPrintRepository.delete(entity);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public void deleteById(Long id) throws Exception {
		Optional<Footprint> footprintOpcional=footPrintRepository.findById(id);
		if(footprintOpcional.isPresent()==false) {
			throw new Exception("El  tipo de documento no existe");
		}
		Footprint entity=footprintOpcional.get();
		delete(entity);
	}

	@Override
	@Transactional(readOnly=true)
	public Long count() {
		return footPrintRepository.count();
	}

	@Override
	public void validate(Footprint footprint) throws Exception {

		if(footprint==null) {
			throw new Exception("El Footprint es nulo");
		}
	    
        Set<ConstraintViolation<Footprint>> constraintViolations = validator.validate(footprint);

        if (constraintViolations.size() > 0) {
            StringBuilder strMessage = new StringBuilder();

            for (ConstraintViolation<Footprint> constraintViolation : constraintViolations) {
                strMessage.append(constraintViolation.getPropertyPath()
                                                     .toString());
                strMessage.append(" - ");
                strMessage.append(constraintViolation.getMessage());
                strMessage.append(". \n");
            }

            throw new Exception(strMessage.toString());
        }

	}

}
