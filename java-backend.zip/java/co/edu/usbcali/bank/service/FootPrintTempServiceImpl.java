package co.edu.usbcali.bank.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.edu.usbcali.bank.domain.FootprintTemp;
import co.edu.usbcali.bank.repository.FootPrintTempRepository;

@Service
public class FootPrintTempServiceImpl implements FootPrintTempService {

	@Autowired
	FootPrintTempRepository FootprintTempRepository;
	
	@Autowired
	Validator validator;
	
	//@Override
	//@Transactional(readOnly=true)
	//@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	//public String createRelease(String release,String result){
	//	return FootprintTempRepository.createRelease(release,result);
	//}		
	
	@Override
	@Transactional(readOnly=true)
	public List<FootprintTemp> findAll() {
		return FootprintTempRepository.findAll();
	}

	@Override
	@Transactional(readOnly=true)
	public Optional<FootprintTemp> findById(Long id) {
		return FootprintTempRepository.findById(id);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public FootprintTemp save(FootprintTemp entity) throws Exception {
		validate(entity);
		return FootprintTempRepository.save(entity);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public FootprintTemp update(FootprintTemp entity) throws Exception {
		validate(entity);
		return FootprintTempRepository.save(entity);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public void delete(FootprintTemp entity) throws Exception {
		if(entity ==null) {
	    	throw new Exception("FootprintTemp Nulo");
	    }
	 
		Optional<FootprintTemp> FootprintTempOpcional=FootprintTempRepository.findById(entity.getFpId());
		if(FootprintTempOpcional.isPresent()==false) {
			throw new Exception("El FootprintTemp "+entity.getFpId()+" no existe");
		}
		
		entity = FootprintTempOpcional.get();						
		FootprintTempRepository.delete(entity);
	}

	@Override
	@Transactional(readOnly=false,propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public void deleteById(Long id) throws Exception {
		Optional<FootprintTemp> FootprintTempOpcional=FootprintTempRepository.findById(id);
		if(FootprintTempOpcional.isPresent()==false) {
			throw new Exception("El  tipo de documento no existe");
		}
		FootprintTemp entity=FootprintTempOpcional.get();
		delete(entity);
	}

	@Override
	@Transactional(readOnly=true)
	public Long count() {
		return FootprintTempRepository.count();
	}

	@Override
	public void validate(FootprintTemp FootprintTemp) throws Exception {

		if(FootprintTemp==null) {
			throw new Exception("El FootprintTemp es nulo");
		}
	    
        Set<ConstraintViolation<FootprintTemp>> constraintViolations = validator.validate(FootprintTemp);

        if (constraintViolations.size() > 0) {
            StringBuilder strMessage = new StringBuilder();

            for (ConstraintViolation<FootprintTemp> constraintViolation : constraintViolations) {
                strMessage.append(constraintViolation.getPropertyPath()
                                                     .toString());
                strMessage.append(" - ");
                strMessage.append(constraintViolation.getMessage());
                strMessage.append(". \n");
            }

            throw new Exception(strMessage.toString());
        }

	}


}
