package co.edu.usbcali.bank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import co.edu.usbcali.bank.domain.Footprint;

public interface FootPrintRepository extends JpaRepository<Footprint, Long> {
	public List<Footprint> findByRelease(String release);
	
	//Ejecuta el sp para crear el footPrint	
	@Transactional	
	@Query(value = "CALL sp_create_release(:p_name,:p_result);", nativeQuery = true)
	public String createRelease(@Param("p_name") String p_name, @Param("p_result") String p_result);
	
	//Ejecuta el sp para comparar
	@Transactional	
	@Query(value = "CALL sp_comparar(:p_release1,:p_release2,:p_result);", nativeQuery = true)
	public String comparar(@Param("p_release1") String release1, @Param("p_release2") String release2,@Param("p_result") String p_result);
				
	//Se puede colocar query nativo
	@Transactional
	@Query(value = "select release,date from footprint group by release,date", nativeQuery = true)	
	public List<Footprint> getAllGroup();
	
	//Se puede colocar query nativo
	/*@Transactional
	@Query(value = "select * from footprint where release=':p_release'", nativeQuery = true)	
	public Optional<Footprint> findByRelease(@Param("p_release") String release);
	*/	
}
