package co.edu.usbcali.bank.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import co.edu.usbcali.bank.domain.Footprint;
import co.edu.usbcali.bank.dto.FootprintDTO;

@Mapper
public interface FootprintMapper {
	FootprintDTO toFootprintDTO(Footprint footprint);
	Footprint toFootprint(FootprintDTO footprintDTO);
	
	List<FootprintDTO> toFootprintDTOs(List<Footprint> footprints);
	List<Footprint> toFootprints(List<FootprintDTO> footprintDTOs);
}
