package co.edu.usbcali.bank.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import co.edu.usbcali.bank.domain.FootprintTemp;
import co.edu.usbcali.bank.dto.FootprintTempDTO;

@Mapper
public interface FootprintTempMapper {
	
	FootprintTempDTO toFootprintTempDTO(FootprintTemp footprintTemp);
	FootprintTemp toFootprintTemp(FootprintTempDTO footprintTempDTO);
	
	List<FootprintTempDTO> toFootprintTempDTOs(List<FootprintTemp> footprintTemps);
	List<FootprintTemp> toFootprintTemps(List<FootprintTempDTO> footprintTempDTOs);
	
}
