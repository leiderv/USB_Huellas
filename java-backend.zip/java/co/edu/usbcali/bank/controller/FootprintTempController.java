package co.edu.usbcali.bank.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import co.edu.usbcali.bank.domain.FootprintTemp;
import co.edu.usbcali.bank.dto.FootprintTempDTO;
import co.edu.usbcali.bank.dto.ResponseErrorDTO;
import co.edu.usbcali.bank.mapper.FootprintTempMapper;
import co.edu.usbcali.bank.service.FootPrintTempService;

@RestController
@RequestMapping("/api/footprintTemp/")
/*se debe adicionar para soluciionar error de cross en el navegador*/
@CrossOrigin("*")
public class FootprintTempController {
	
	@Autowired
	FootPrintTempService  footprintTempService;
	
	@Autowired
	FootprintTempMapper footprintTempMapper;
	
	/*@GetMapping("createRelease/{release}")
	public ResponseEntity<?> createRelease(@PathVariable("release")String release) {
		String footprintResult=footprintTempService.createRelease(release,"");
		if(footprintResult=="0") {
			return ResponseEntity.badRequest().body(new ResponseErrorDTO("400","No se genero version"));
		}				
		FootprintDTO footprintDTO = new FootprintDTO();
		footprintDTO.setRelease(footprintResult);
		return ResponseEntity.ok().body(footprintDTO);
	}*/
	
	@GetMapping("findAll")
	public ResponseEntity<?> findAll(){
		List<FootprintTemp> footprintTemps=footprintTempService.findAll();
		List<FootprintTempDTO> footprintTempDTOs=footprintTempMapper.toFootprintTempDTOs(footprintTemps);
		return ResponseEntity.ok().body(footprintTempDTOs);
	}
	
	@GetMapping("findById/{id}")
	public ResponseEntity<?> findById(@PathVariable("id")Long id) {
		Optional<FootprintTemp> footprintTempOptional=footprintTempService.findById(id);
		if(footprintTempOptional.isPresent()==false) {
			return ResponseEntity.badRequest().body(new ResponseErrorDTO("400","El footprint no existe"));
		}		
		FootprintTemp footprintTemp=footprintTempOptional.get();
		FootprintTempDTO footprintTempDTO=footprintTempMapper.toFootprintTempDTO(footprintTemp);
		return ResponseEntity.ok().body(footprintTempDTO);
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleValidationExceptions(
	  MethodArgumentNotValidException ex) {
		StringBuilder strMessage = new StringBuilder();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        strMessage.append(fieldName);
	        strMessage.append("-");
	        strMessage.append(errorMessage);
	    });
	    return ResponseEntity
	    		.badRequest().
	    		body(new ResponseErrorDTO("400",strMessage.toString()));
	}
}

