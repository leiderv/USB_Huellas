package co.edu.usbcali.bank.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import co.edu.usbcali.bank.domain.Footprint;
import co.edu.usbcali.bank.dto.FootprintDTO;
import co.edu.usbcali.bank.dto.ResponseErrorDTO;
import co.edu.usbcali.bank.mapper.FootprintMapper;
import co.edu.usbcali.bank.service.FootPrintService;

@RestController
@RequestMapping("/api/footprint/")
/*se debe adicionar para soluciionar error de cross en el navegador*/
@CrossOrigin("*")
public class FootprintController {
	
	@Autowired
	FootPrintService  footprintService;
	
	@Autowired
	FootprintMapper footprintMapper;
	
	@GetMapping("createRelease/{release}")
	public ResponseEntity<?> createRelease(@PathVariable("release")String release) {
		String footprintResult=footprintService.createRelease(release,"");
		if(footprintResult=="0") {
			return ResponseEntity.badRequest().body(new ResponseErrorDTO("400","No se genero version"));
		}				
		FootprintDTO footprintDTO = new FootprintDTO();
		footprintDTO.setRelease(footprintResult);
		return ResponseEntity.ok().body(footprintDTO);
	}
	
	@GetMapping("comparar/{release1}/{release2}")
	public ResponseEntity<?> comparar(@PathVariable("release1")String release1,@PathVariable("release2")String release2) {
		String footprintResult=footprintService.comparar(release1,release2,"");
		if(footprintResult=="0") {
			return ResponseEntity.badRequest().body(new ResponseErrorDTO("400","No se genero version"));
		}				
		FootprintDTO footprintDTO = new FootprintDTO();
		footprintDTO.setRelease(footprintResult);
		return ResponseEntity.ok().body(footprintDTO);
	}
	
	/*@GetMapping("getAllGroup")
	public ResponseEntity<?> getAllGroup(){
		List<Footprint> footprints=footprintService.getAllGroup();
		List<FootprintDTO> footprintDTOs=footprintMapper.toFootprintDTOs(footprints);
		return ResponseEntity.ok().body(footprintDTOs);
	}*/
	
	@GetMapping("findAll")
	public ResponseEntity<?> findAll(){
		List<Footprint> footprints=footprintService.findAll();
		List<FootprintDTO> footprintDTOs=footprintMapper.toFootprintDTOs(footprints);
		return ResponseEntity.ok().body(footprintDTOs);
	}
	
	@GetMapping("findByRelease/{id}")
	public ResponseEntity<?> findByRelease(@PathVariable("id")String id) {
		List<Footprint> footprints=footprintService.findByRelease(id);
		List<FootprintDTO> footprintDTOs=footprintMapper.toFootprintDTOs(footprints);
		return ResponseEntity.ok().body(footprintDTOs);		
	}
	
	@GetMapping("findById/{id}")
	public ResponseEntity<?> findById(@PathVariable("id")Long id) {
		Optional<Footprint> footprintOptional=footprintService.findById(id);
		if(footprintOptional.isPresent()==false) {
			return ResponseEntity.badRequest().body(new ResponseErrorDTO("400","El footprint no existe"));
		}		
		Footprint footprint=footprintOptional.get();
		FootprintDTO footprintDTO=footprintMapper.toFootprintDTO(footprint);
		return ResponseEntity.ok().body(footprintDTO);
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleValidationExceptions(
	  MethodArgumentNotValidException ex) {
		StringBuilder strMessage = new StringBuilder();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        strMessage.append(fieldName);
	        strMessage.append("-");
	        strMessage.append(errorMessage);
	    });
	    return ResponseEntity
	    		.badRequest().
	    		body(new ResponseErrorDTO("400",strMessage.toString()));
	}
}
