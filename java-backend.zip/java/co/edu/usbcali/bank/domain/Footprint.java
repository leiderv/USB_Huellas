package co.edu.usbcali.bank.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "footprint", schema = "public")
public class Footprint implements java.io.Serializable {
	/*no lleva el NotNull porque este se autoincrementa*/
	private Long fpId;
	
	@NotNull
	@NotEmpty
	@Size(max = 255)
	private String release;
	
	@NotNull
	@NotEmpty
	@Size(max = 255)	
	private String object_type;
	
	@NotNull
	@NotEmpty
	@Size(max = 255)
	private String object;
	
	@NotNull
	private String date;
	
	@NotNull
	@NotEmpty	
	private String hash;

	public Footprint() {
	}

	public Footprint(Long fpId, String release, String object_type, String object, String date, String hash) {
		this.fpId = fpId;
		this.release = release;
		this.object_type = object_type;
		this.object = object;
		this.date = date;
		this.hash = hash;
	}
		
	@Id
	@Column(name = "fp_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getFpId() {
		return this.fpId;
	}

	public void setFpId(Long fpId) {
		this.fpId = fpId;
	}

	
	@Column(name = "release", nullable = false)
	public String getRelease() {
		return this.release;
	}

	public void setRelease(String release) {
		this.release = release;
	}
	
	@Column(name = "object_type", nullable = false)
	public String getObject_type() {
		return this.object_type;
	}

	public void setObject_type(String object_type) {
		this.object_type = object_type;
	}
	
	@Column(name = "object", nullable = false)
	public String getObject() {
		return this.object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	@Column(name = "date", nullable = false)
	public String getDate() {
		return this.date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	@Column(name = "hash", nullable = false)
	public String getHash() {
		return this.hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}	
}
